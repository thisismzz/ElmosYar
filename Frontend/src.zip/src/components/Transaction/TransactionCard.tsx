import { ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { getPostById } from '../../services/PostService';
import { useEffect, useState } from 'react';

interface Transaction {
  id: string;
  amount: number;
  title: string;
  user: string;
  type: 'withdraw' | 'deposit' | 'payment';
  date: string;
}

interface TransactionCardProps {
  transaction: Transaction;
  postId: number
}

export function TransactionCard({ transaction, postId }: TransactionCardProps) {
  const isDepositOrPayment = transaction.type === "deposit";
  const [name, setName] = useState();
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  	useEffect(() => {
		const get_post_title = async () => {
			setName( (await getPostById(postId)).attributes.name);
		}
		
	})
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1">
          <div className={`rounded-full p-2.5 ${
            isDepositOrPayment ? 'bg-green-100' : 'bg-red-100'
          }`}>
            {isDepositOrPayment ? (
              <ArrowDownLeft className="w-5 h-5 text-green-600" />
            ) : (
              <ArrowUpRight className="w-5 h-5 text-red-600" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="flex text-gray-900 mb-1">{transaction.title}</h3>
            <p className="text-gray-600 text-sm mb-1">
              {/* {transaction.user} :{isDepositOrPayment ? 'از' : 'به'} */}
            <p className="text-gray-500 text-sm">
              {name}
            </p>
            </p>
          </div>
        </div>

        <div className="text-right">
          <p className={`mb-1 ${
            isDepositOrPayment ? 'text-green-600' : 'text-red-600'
          }`}>
            {isDepositOrPayment ? '+' : '-'}${transaction.amount.toFixed(2)}
          </p>
          <span className={`inline-block px-2.5 py-1 rounded-full text-xs ${
            isDepositOrPayment 
              ? 'bg-green-100 text-green-700' 
              : 'bg-red-100 text-red-700'
          }`}>
            {transaction.type === "payment" ? 'پرداخت' :
			 transaction.type === "deposit" ? 'واریز' : 
			 "برداشت"}
          </span>
        </div>
      </div>
    </div>
  );
}
